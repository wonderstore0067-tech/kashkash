const db = require('../config/db');
const generateToken = require('../utils/jwt');
const { hashPassword, comparePassword } = require('../utils/password');

exports.getAllUsers = (req, res) => {
  const sql = 'SELECT * FROM users';

  db.query(sql, (err, results) => {
    if (err) {
      console.error('Error fetching users:', err);
      return res.status(500).json({
        success: false,
        message: 'Error fetching users',
      });
    }

    res.status(200).json({
      success: true,
      users: results,
    });
  });
};

exports.getSingleUser = async (req, res) => {
  const userId = req.params.id; // Assuming you're passing the user ID as a URL parameter

  try {
    const checkUser = 'SELECT * FROM users WHERE id = ?';
    db.query(checkUser, [userId], (checkErr, checkResult) => {
      if (checkErr) {
        console.error('Error checking user:', checkErr);
        return res.status(500).json({
          success: false,
          message: 'Error checking user',
        });
      }

      if (checkResult.length === 0) {
        return res.status(404).json({
          success: false,
          message: 'User not found',
        });
      } else {
        res.status(200).json({
          success: true,
          userId: checkResult[0].id,
          userName: checkResult[0].name,
          userEmail: checkResult[0].email,
          userAccount_Id: checkResult[0].account_id,
          userPrivate_Key: checkResult[0].private_key,
        });
      }
    });
  } catch (error) {
    console.error('Error finding user:', error);
    res.status(500).json({
      success: false,
      message: 'Error finding user',
    });
  }
};

exports.signupUser = async (req, res) => {
  const { name, email, password, account_id, private_key } = req.body;

  try {
    // Hash the password
    const hashedPassword = await hashPassword(password);

    const query = 'SELECT * FROM users WHERE email = ?';
    db.query(query, [email], async (err, results) => {
      if (err) {
        console.error('Error:', err);
        return res.status(500).json({ message: 'Database error' });
      }

      if (results.length > 0) {
        return res.json({ message: 'Email already exist' });
      } else {
        const sql =
          'INSERT INTO users (name, email, password, account_id, private_key) VALUES (?, ?, ?, ?, ?)';
        db.query(
          sql,
          [name, email, hashedPassword, account_id, private_key],
          (err, result) => {
            if (err) {
              console.error('Error signing up user:', err);
              return res.status(500).json({
                success: false,
                message: 'Error signing up user',
              });
            }

            // Generate JWT token
            const token = generateToken(result.insertId);

            res.status(201).json({
              success: true,
              message: 'User signed up successfully',
              token, // Include the token in the response
            });
          }
        );
      }
    });
  } catch (error) {
    console.error('Error signing up user:', error);
    res.status(500).json({
      success: false,
      message: 'Error signing up user',
    });
  }
};
exports.loginUser = async (req, res) => {
  const { email, password } = req.body;

  try {
    if (!email || !password) {
      return res
        .status(400)
        .json({ message: 'Please Enter Email And Password' });
    }

    // Check if the user with the given email exists
    const query = 'SELECT * FROM users WHERE email = ?';
    db.query(query, [email], async (err, results) => {
      if (err) {
        console.error('Error:', err);
        return res.status(500).json({ message: 'Database error' });
      }

      if (results.length > 0) {
        const user = results[0];

        // Compare the provided password with the hashed password from the database
        const passwordMatch = await comparePassword(password, user.password);

        if (!passwordMatch) {
          return res
            .status(401)
            .json({ message: 'Email or Password is not valid' });
        }

        const options = {
          expires: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000 ),
          httpOnly: true
        };

        // Generate JWT token
        const token = generateToken(user.id);

        res.status(200)
        .cookie("token", token, options)
        .json({
          user: user.name,
          success: true,
          token,
        });
      } else {
        console.log('User not found');
        return res.status(401).json({ message: 'Email is not valid' });
      }
    });
  } catch (error) {
    console.error('Error logging in:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

exports.updateUser = async (req, res) => {
  const userId = req.params.id;
  const { name, email, account_id, private_key } = req.body;

  try {
    const sql =
      'UPDATE users SET name = ?, email = ?, account_id = ?, private_key = ? WHERE id = ?';
    db.query(
      sql,
      [name, email, account_id, private_key, userId],
      (err, result) => {
        if (err) {
          console.error('Error updating user:', err);
          return res.status(500).json({
            success: false,
            message: 'Error updating user',
          });
        }

        res.status(200).json({
          success: true,
          message: 'User updated successfully',
        });
      }
    );
  } catch (error) {
    console.error('Error updating user:', error);
    res.status(500).json({
      success: false,
      message: 'Error updating user',
    });
  }
};

exports.updateUserProfile = async (req, res) => {
  const userId = req.userId; // Get the user ID from the token
  const { name, email, account_id, private_key } = req.body;

  try {
    const sql =
      'UPDATE users SET name = ?, email = ?, account_id = ?, private_key = ? WHERE id = ?';
    db.query(
      sql,
      [name, email, account_id, private_key, userId],
      (err, result) => {
        if (err) {
          console.error('Error updating user profile:', err);
          return res.status(500).json({
            success: false,
            message: 'Error updating user profile',
          });
        }

        res.status(200).json({
          success: true,
          message: 'User profile updated successfully',
        });
      }
    );
  } catch (error) {
    console.error('Error updating user profile:', error);
    res.status(500).json({
      success: false,
      message: 'Error updating user profile',
    });
  }
};

exports.deleteUser = async (req, res) => {
  const userId = req.params.id; // Assuming you're passing the user ID as a URL parameter

  try {
    const checkUserSql = 'SELECT * FROM users WHERE id = ?';
    db.query(checkUserSql, [userId], (checkErr, checkResult) => {
      if (checkErr) {
        console.error('Error checking user:', checkErr);
        return res.status(500).json({
          success: false,
          message: 'Error checking user',
        });
      }

      if (checkResult.length === 0) {
        return res.status(404).json({
          success: false,
          message: 'User not found',
        });
      }

      const deleteSql = 'DELETE FROM users WHERE id = ?';
      db.query(deleteSql, [userId], (deleteErr, deleteResult) => {
        if (deleteErr) {
          console.error('Error deleting user:', deleteErr);
          return res.status(500).json({
            success: false,
            message: 'Error deleting user',
          });
        }

        res.status(200).json({
          success: true,
          message: 'User deleted successfully',
        });
      });
    });
  } catch (error) {
    console.error('Error deleting user:', error);
    res.status(500).json({
      success: false,
      message: 'Error deleting user',
    });
  }
};
