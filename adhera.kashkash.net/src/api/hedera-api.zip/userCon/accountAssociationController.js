const db = require('../config/db');

// Function to handle sending transactions

exports.checkAssociation = async (req, res) => {
  const account_id = req.params.id;

  const sql = 'Select * FROM account_association WHERE operator_id = ?';
  db.query(sql, [account_id], (err, results) => {
    if (err) {
      console.error('Error fetching transactions:', err);
      return res.status(500).json({
        success: false,
        message: 'Error fetching transactions',
      });
    }
    operator_id = results;

    if (operator_id.length == 0) {
      res.status(404).json({
        success: false,
        message: 'Id Not Found',
      });
    } else {
      res.status(200).json({
        success: true,
      });
    }
  });
};

exports.addAssociation = async (req, res) => {
  const operator_id = req.body.operator_id;
  const status = 1;
  const sql1 =
    'INSERT INTO account_association (operator_id,status)  VALUES (?, ?)';
  db.query(sql1, [operator_id, status], (err, results) => {
    if (err) {
      console.error('Error fetching transactions:', err);
      return res.status(500).json({
        success: false,
        message: 'Error in registration',
      });
    }

    res.status(200).json({
      success: true,
      operator: operator_id,
    });
  });
};
