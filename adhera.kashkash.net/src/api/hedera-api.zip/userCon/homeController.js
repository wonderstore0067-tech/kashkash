const db = require('../config/db');

exports.dashboardData = async (req, res) => {
  const transCountSql = 'SELECT COUNT(*) AS totalTransactions FROM transactions';
  const totalUsersSql = 'SELECT COUNT(*) AS totalUsers FROM users';
  const totalTransactionsAmountSql = 'SELECT SUM(amount) AS totalAmount FROM transactions';
  const userId = req.userId;
  console.log(userId);

  // Query to find the total amount sent by the user
  const userAmountSendSql = `
    SELECT SUM(t.amount) AS my_debit
    FROM transactions AS t
    JOIN users AS r ON t.sender_account = r.account_id
    WHERE r.id = ?`;

  // Query to find the total amount received by the user
  const userAmountReceiveSql = `
    SELECT SUM(t.amount) AS my_credit
    FROM transactions AS t
    JOIN users AS r ON t.receiver_account = r.account_id
    WHERE r.id = ?`;

    // Now, execute the second query to get the transaction count
    db.query(transCountSql, (err, transCountResults) => {
      if (err) {
        console.error('Error fetching transaction count:', err);
        return res.status(500).json({
          success: false,
          message: 'Error fetching transaction count',
        });
      }

      // Retrieve the count from the result of the second query
      const totalTransactions = transCountResults[0].totalTransactions;

      // Now, execute the query to get the total number of users
      db.query(totalUsersSql, (err, totalUsersResults) => {
        if (err) {
          console.error('Error fetching total users:', err);
          return res.status(500).json({
            success: false,
            message: 'Error fetching total users',
          });
        }

        // Retrieve the total number of users from the result
        const totalUsers = totalUsersResults[0].totalUsers;

        // Now, execute the query to get the total transaction amount
        db.query(totalTransactionsAmountSql, (err, totalAmountResults) => {
          if (err) {
            console.error('Error fetching total transaction amount:', err);
            return res.status(500).json({
              success: false,
              message: 'Error fetching total transaction amount',
            });
          }

          // Retrieve the total transaction amount from the result
          const totalAmount = totalAmountResults[0].totalAmount;

          // Now, execute the query to get the amount sent by the user
          db.query(
            userAmountSendSql,
            [userId],
            (err, userAmountSendResults) => {
              if (err) {
                console.error('Error fetching user amount sent:', err);
                return res.status(500).json({
                  success: false,
                  message: 'Error fetching user amount sent',
                });
              }

              // Retrieve the user's amount sent from the result
              const userAmountSent = userAmountSendResults[0].my_debit;

              // Now, execute the query to get the amount received by the user
              db.query(
                userAmountReceiveSql,
                [userId],
                (err, userAmountReceiveResults) => {
                  if (err) {
                    console.error('Error fetching user amount received:', err);
                    return res.status(500).json({
                      success: false,
                      message: 'Error fetching user amount received',
                    });
                  }

                  // Retrieve the user's amount received from the result
                  const userAmountReceived =
                    userAmountReceiveResults[0].my_credit;

                  // Return all data in the response
                  res.status(200).json({
                    success: true,
                    TotalTransactions: totalTransactions,
                    TotalUsers: totalUsers,
                    TotalAmount: totalAmount,
                    UserAmountSent: userAmountSent,
                    UserAmountReceived: userAmountReceived,
                  });
                }
              );
            }
          );
        });
      });
    });
};