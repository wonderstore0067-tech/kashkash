const db = require('../config/db');

exports.getAllTransactions = async (req, res) => {
  const sql = 'SELECT * FROM transactions';
 
  db.query(sql, (err, results) => {
    if (err) {
      console.error('Error fetching transactions:', err);
      return res.status(500).json({
        success: false,
        message: 'Error fetching transactions',
      });
    }

    res.status(200).json({
      success: true,
      Transactions: results
    });
  });
};
