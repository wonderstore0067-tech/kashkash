const axios = require("axios");
const { 
    Client, 
    PrivateKey, 
    AccountId, 
    TransferTransaction, 
    TokenAssociateTransaction, 
    TokenId
} = require("@hashgraph/sdk");

exports.sendAmount = async (req, res) => {

  console.log("checking id ", req.userId);
  let myAccountId = '';
  let myPrivateKey = '';

  const {token} = req.cookies;

  console.log("tokkken", token);

  try {
    const response = await axios.get(`http://localhost:3000/api/v1/singleuser/${req.userId}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
    myAccountId = response.data.userAccount_Id;
    myPrivateKey = response.data.userPrivate_Key;

  } catch (error) {
    res.status(500).json({
        success: false,
        message: error.message
    });
  }
  console.log(myAccountId, myPrivateKey);
  const { 
        newAccountId, 
        newAccountPrivateKey, 
        amount 
    } = req.body;

  try {
    const client = Client.forTestnet().setOperator(AccountId.fromString(myAccountId), PrivateKey.fromString(myPrivateKey));
    const receiverClient = Client.forTestnet().setOperator(AccountId.fromString(newAccountId), PrivateKey.fromString(newAccountPrivateKey));
    const tokenIdToTransfer = TokenId.fromString("0.0.486746");

    // Check if both sender and receiver are associated with the token
    // Implement your association logic here

    let firstAssociation = false;
    let secondAssociation = false;

    
    try {
        const response = await axios.get(`http://localhost:3000/api/v1/checkAssociation/${myAccountId}`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        firstAssociation = response.data.success;
      } catch (error) {
        console.error("Error fetching association for myAccountId:", error);
      }
      
      try {
        const secresponse = await axios.get(`http://localhost:3000/api/v1/checkAssociation/${newAccountId}`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        secondAssociation = secresponse.data.success;
      } catch (error) {
        console.error("Error fetching association for newAccountId:", error.response.data);
      }
      




      if (firstAssociation === false) {
        let myAssociation = { operator_id: myAccountId };
      
        try {
          const associationResponse = await axios.post(
            'http://localhost:3000/api/v1/addAssociation',
            myAssociation,
            {
              headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json', // Set the content type if needed
              },
            }
          );
          console.log("Association Success");
        } catch (error) {
          console.error('Error in association:', error);
        }
      
        try {
          const associateSenderTx = new TokenAssociateTransaction()
            .setAccountId(myAccountId)
            .setTokenIds([tokenIdToTransfer]);
          await associateSenderTx.execute(client);
        } catch (error) {
          if (error.message.includes("TOKEN_ALREADY_ASSOCIATED_TO_ACCOUNT")) {
            console.log(`Token already associated with sender account.`);
          } else {
            console.error("Error associating token with sender:", error);
            return;
          }
        }
      }
      
      if (secondAssociation === false) {
        let newAssociation = { operator_id: newAccountId };
      
        try {
          const associationResponse = await axios.post(
            'http://localhost:3000/api/v1/addAssociation',
            newAssociation,
            {
              headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json', // Set the content type if needed
              },
            }
          );
          console.log("Association Success");
        } catch (error) {
          console.error('Error in association:', error);
        }
      
        try {
          const associateReceiverTx = new TokenAssociateTransaction()
            .setAccountId(newAccountId)
            .setTokenIds([tokenIdToTransfer]);
          await associateReceiverTx.execute(receiverClient);
        } catch (error) {
          if (error.message.includes("TOKEN_ALREADY_ASSOCIATED_TO_ACCOUNT")) {
            console.log(`Token already associated with receiver account.`);
          } else {
            console.error("Error associating token with receiver:", error);
            return;
          }
        }
      }


    // Transfer tokens from sender to receiver
    const transferTx = new TransferTransaction()
      .addTokenTransfer(tokenIdToTransfer, AccountId.fromString(myAccountId), -amount)
      .addTokenTransfer(tokenIdToTransfer, AccountId.fromString(newAccountId), amount)
      .freezeWith(client);

    const transferTxResponse = await transferTx.execute(client);
    const transferReceipt = await transferTxResponse.getReceipt(client);
    
    const transferTxHash = transferTxResponse.transactionId.toString();



    res.json({ status: "success", message: "Transaction completed successfully" });
  } catch (error) {
    res.status(500).json({ status: "error", message: "Error processing transaction" });
  }
};
