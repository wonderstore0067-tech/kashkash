const express = require('express');
const dotenv = require('dotenv').config();
const cookieParser = require("cookie-parser");

const app = express();
const user = require('./routes/userRoute');
const transactions = require('./routes/transactionRoute');
// const sendTransactionRoute = require('./routes/sendTransactionRoute');

app.use(express.json());
app.use(cookieParser());

app.use('/api/v1', user);
app.use('/api/v1', transactions);
// app.use('/api', sendTransactionRoute);

const port = 3000;

app.listen(port, () => {
  console.log(`Server is running on Port : ${port}`);
});
