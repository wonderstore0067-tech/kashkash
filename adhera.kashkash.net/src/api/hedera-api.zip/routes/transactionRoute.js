const express = require('express');
const authenticateUser = require('../middleware/auth');
const { getAllTransactions } = require('../userCon/transactionController');
const { sendAmount } = require('../userCon/sendAmountController');
const { checkAssociation, addAssociation } = require('../userCon/accountAssociationController');

const router = express.Router();

router.route('/getalltransactions').get(authenticateUser, getAllTransactions);
router.route('/sendAmount').post(authenticateUser, sendAmount);

router.route('/checkAssociation/:id').get(authenticateUser, checkAssociation);
router.route('/addAssociation').post(authenticateUser, addAssociation);

module.exports = router;
