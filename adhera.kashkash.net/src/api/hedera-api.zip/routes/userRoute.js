const express = require('express');
const {
  getAllUsers,
  signupUser,
  loginUser,
  updateUser,
  deleteUser,
  getSingleUser,
  updateUserProfile,
} = require('../userCon/userController');
const authenticateUser = require('../middleware/auth');
const { dashboardData } = require('../userCon/homeController');
const router = express.Router();

router.route('/dashboard').get(authenticateUser, dashboardData);
router.route('/getallusers').get(authenticateUser, getAllUsers);
router.route('/updateprofile').put(authenticateUser, updateUserProfile);

router.route('/signup').post(signupUser);
router.route('/login').post(loginUser);
router.route('/singleuser/:id').get(authenticateUser, getSingleUser);
router.route('/update/:id').put(authenticateUser, updateUser);
router.route('/delete/:id').delete(authenticateUser, deleteUser);

module.exports = router;
